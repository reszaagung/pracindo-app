import { computed, reactive, ref, watch } from 'vue'
import api from '@/utils/api'
import { bacaError } from '@/utils/error'

const buatIdemKey = () => `setor:${crypto?.randomUUID?.() || Date.now() + '-' + Math.random()}`
const hariIni = () => new Date().toISOString().split('T')[0]
const angka = (v) => {
    const n = Number(String(v ?? '').replace(',', '.'))
    return Number.isFinite(n) ? n : 0
}

export function useFormPoolRaw(emit, { grupBahan = [] } = {}) {
    const form = reactive({
        entitas_asal_id: '',
        grup_bahan_id: '',
        tanggal: hariIni(),
        catatan: '',
    })

    const barisKosong = () => ({ stok_id: '', qty: '' })
    const bahan = ref([barisKosong(), barisKosong()])
    const idemKey = ref(buatIdemKey())

    const opsi = reactive({
        grup: grupBahan,
        stokGudang: [],
    })

    const memuat = reactive({ awal: false, kirim: false })
    const galatServer = ref(null)
    const sudahDicoba = ref(false)

    async function muatDataAwal() {
        memuat.awal = true
        galatServer.value = null
        try {
            const { data } = await api.get('inventory/stok/', {
                params: { lapis: 'RAW', ada_isi: '1' }
            })
            opsi.stokGudang = data.results || data || []
        } catch (err) {
            galatServer.value = { message: bacaError(err, 'Gagal memuat stok Bahan Mentah (RAW).') }
        } finally {
            memuat.awal = false
        }
    }

    const opsiEntitasAsal = computed(() => {
        const map = new Map()
        opsi.stokGudang.forEach(s => {
            let id = s.grup_bahan_id || s.entitas_id || (s.grup_bahan && s.grup_bahan.id) || s.grup_bahan
            let kode = s.grup_bahan_kode || s.entitas_kode || (s.grup_bahan && s.grup_bahan.kode) || s.grup_bahan || `Entitas ${id}`

            if (id !== undefined && id !== null && !map.has(id)) {
                map.set(id, { id, kode })
            }
        })
        return Array.from(map.values())
    })

    const stokById = (id) => opsi.stokGudang.find((s) => String(s.id) === String(id))

    function opsiUntukBaris(i) {
        if (!form.entitas_asal_id) return []

        const terpakai = bahan.value
            .map((b, j) => (j === i ? null : b.stok_id))
            .filter(Boolean)
            .map(String)

        return opsi.stokGudang.filter((s) => {
            let idEntitasStok = s.grup_bahan_id || s.entitas_id || (s.grup_bahan && s.grup_bahan.id) || s.grup_bahan

            const isSesuaiEntitas = String(idEntitasStok) === String(form.entitas_asal_id)
            const isBelumDipakai = !terpakai.includes(String(s.id))

            return isSesuaiEntitas && isBelumDipakai
        })
    }

    watch(() => form.entitas_asal_id, () => {
        bahan.value = [barisKosong(), barisKosong()]
    })

    const barisTerisi = computed(() => bahan.value.filter((b) => b.stok_id && angka(b.qty) > 0))
    const totalBahan = computed(() => barisTerisi.value.reduce((t, b) => t + angka(b.qty), 0))

    const galat = computed(() => {
        const g = {}
        if (!form.entitas_asal_id) g.entitas_asal_id = 'Pilih entitas pemilik bahan.'
        if (!form.grup_bahan_id) g.grup_bahan_id = 'Pilih Pool tujuan peleburan.'
        if (!form.tanggal) g.tanggal = 'Tanggal wajib diisi.'
        if (!barisTerisi.value.length) g.baris = 'Isi minimal satu bahan yang akan ditransfer.'

        bahan.value.forEach((b, i) => {
            if (b.stok_id && angka(b.qty) > 0) {
                const s = stokById(b.stok_id)
                if (s && angka(b.qty) > angka(s.qty)) {
                    g[`baris_${i}`] = `Maksimal transfer ${s.qty} kg.`
                }
            }
        })
        return g
    })

    const bisaKirim = computed(() => Object.keys(galat.value).length === 0 && !memuat.kirim)

    function tambahBaris() { bahan.value.push(barisKosong()) }
    function hapusBaris(i) { if (bahan.value.length > 1) bahan.value.splice(i, 1) }

    function reset() {
        form.catatan = ''
        form.entitas_asal_id = ''
        bahan.value = [barisKosong(), barisKosong()]
        sudahDicoba.value = false
        idemKey.value = buatIdemKey()
    }

    async function kirim() {
        sudahDicoba.value = true
        galatServer.value = null
        if (!bisaKirim.value) return

        memuat.kirim = true
        try {
            const daftarPengiriman = barisTerisi.value.map((b, index) => {
                const s = stokById(b.stok_id)
                const idProduk = s.produk_id || (s.produk && s.produk.id)

                const payload = {
                    entitas_id: Number(form.entitas_asal_id),
                    grup_bahan_id: Number(form.grup_bahan_id),
                    produk_id: Number(idProduk),
                    qty: (Math.round(angka(b.qty) * 1000) / 1000).toFixed(3),
                    tanggal: form.tanggal,
                    catatan: form.catatan.trim(),
                    idem_key: `${idemKey.value}-${index}`
                }

                return api.post('inventory/setor-ke-pool/', payload)
            })

            await Promise.all(daftarPengiriman)

            emit('tersimpan', { sukses: true })
            reset()
        } catch (err) {
            galatServer.value = { message: bacaError(err, 'Gagal mengeksekusi transfer ke Pool.') }
        } finally {
            memuat.kirim = false
        }
    }

    const tampilkan = (kunci) => sudahDicoba.value && galat.value[kunci]
    const galatBaris = (i) => sudahDicoba.value ? galat.value[`baris_${i}`] : null

    return {
        form, bahan, opsi, memuat, galatServer, galat, bisaKirim, totalBahan,
        opsiEntitasAsal, muatDataAwal, stokById, opsiUntukBaris, tambahBaris, hapusBaris, kirim, reset,
        tampilkan, galatBaris
    }
}