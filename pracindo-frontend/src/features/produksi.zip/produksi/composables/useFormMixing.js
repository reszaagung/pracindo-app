/* ===============================================================
   useFormMixing.js — form sesi produksi / R&D

   DISAMBUNGKAN ULANG KE KONTRAK BACKEND YANG SEBENARNYA.
   Catatan lengkap tiap perubahan ada di API-CATATAN-SAMBUNGAN.md.

   TIDAK ADA TOKEN DI BERKAS INI. Autentikasi memakai session 
   cookie Django + header CSRF. Dilengkapi Idempotency Key.
   =============================================================== */
import { computed, reactive, ref, watch } from 'vue'

const API = {
    stok: '/api/v1/inventory/stok/',
    tangki: '/api/v1/inventory/tangki/',
    resep: '/api/v1/produksi/resep/',
    sesi: '/api/v1/produksi/sesi/',
    sesiRnd: '/api/v1/produksi/sesi/rnd/',
    kapasitas: '/api/v1/produksi/kapasitas/',
}

const TANGKI_BARU_TERSEDIA = false

/* ---------------------------------------------------------------
   Transport & Helpers
--------------------------------------------------------------- */
function csrfToken() {
    return document.cookie.match(/(?:^|;\s*)csrftoken=([^;]*)/)?.[1] ?? ''
}

const buatIdemKey = () => `sesi:${crypto?.randomUUID?.() || Date.now() + '-' + Math.random()}`

async function bacaGalat(r) {
    let isi
    try { isi = await r.json() } catch { isi = { detail: `HTTP ${r.status}` } }

    const perField = {}
    let pesan = isi.detail
    if (!pesan) {
        for (const [k, v] of Object.entries(isi)) {
            perField[k] = Array.isArray(v) ? v.join(' ') : String(v)
        }
        pesan = Object.entries(perField)
            .map(([k, v]) => `${k}: ${v}`)
            .join('\n') || `HTTP ${r.status}`
    }

    const e = new Error(pesan)
    e.rincian = isi
    e.perField = perField
    e.status = r.status
    return e
}

async function apiGet(url, params = {}) {
    const q = new URLSearchParams(
        Object.entries(params).filter(([, v]) => v !== null && v !== '' && v !== undefined)
    )
    const r = await fetch(`${url}?${q}`, {
        credentials: 'include',
        headers: { Accept: 'application/json' },
    })
    if (!r.ok) throw await bacaGalat(r)
    return r.json()
}

async function apiGetList(url, params = {}) {
    const d = await apiGet(url, params)
    return Array.isArray(d) ? d : (d.results ?? [])
}

async function apiPost(url, body) {
    const r = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRFToken': csrfToken(),
            Accept: 'application/json',
        },
        body: JSON.stringify(body),
    })
    if (!r.ok) throw await bacaGalat(r)
    return r.json()
}

const angka = (v) => {
    const n = Number(String(v ?? '').replace(',', '.'))
    return Number.isFinite(n) ? n : 0
}
const qty3 = (n) => (Math.round(angka(n) * 1000) / 1000).toFixed(3)
const tampil = (n) => angka(n).toLocaleString('id-ID', {
    minimumFractionDigits: 3, maximumFractionDigits: 3,
})

function hariIni() {
    const d = new Date()
    const p = (x) => String(x).padStart(2, '0')
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

/* ---------------------------------------------------------------
   Composable Utama
--------------------------------------------------------------- */
export function useFormMixing(emit, { grupBahan = [] } = {}) {

    const form = reactive({
        jenis_sesi: 'PRODUKSI',
        grup_bahan_id: '',
        tanggal: hariIni(),
        resep_id: '',
        produk_jadi_id: '',
        hasil_masuk_pool: true,
        mode_tangki: 'ada',
        tangki_hasil_id: '',
        tangki_baru: { kode: '', nama: '', kapasitas_kg: '' },
        target_hasil: '',
        catatan: '',
    })

    const barisKosong = () => ({ stok_id: '', qty: '' })
    const bahan = ref([barisKosong(), barisKosong(), barisKosong()])

    // Kunci Idempotensi di-generate sekali saat form dibuka
    const idemKey = ref(buatIdemKey())

    const opsi = reactive({
        grup: grupBahan,
        resep: [],
        stokPool: [],
        tangki: [],
        kapasitas: null,
    })
    const memuat = reactive({ awal: false, grup: false, kapasitas: false, kirim: false })
    const galatServer = ref(null)
    const sudahDicoba = ref(false)

    /* ---------------- Pemuatan Data ---------------- */
    async function muatDataAwal() {
        memuat.awal = true
        galatServer.value = null
        try {
            opsi.resep = await apiGetList(API.resep)
        } catch (e) {
            galatServer.value = e
        } finally {
            memuat.awal = false
        }
    }

    async function muatIsiGrup(grupId) {
        opsi.stokPool = []
        opsi.tangki = []
        if (!grupId) return

        memuat.grup = true
        try {
            const [stok, tangki] = await Promise.all([
                apiGetList(API.stok, { lapis: 'POOL', grup: grupId, ada_isi: '1' }),
                apiGetList(API.tangki, { grup: grupId, aktif: '1' }),
            ])
            opsi.stokPool = stok
            opsi.tangki = tangki
        } catch (e) {
            galatServer.value = e
        } finally {
            memuat.grup = false
        }
    }

    async function muatKapasitas() {
        opsi.kapasitas = null
        const grupId = form.grup_bahan_id
        const produkId = produkJadiId.value
        if (!grupId || !produkId || form.jenis_sesi !== 'PRODUKSI') return

        memuat.kapasitas = true
        try {
            opsi.kapasitas = await apiGet(API.kapasitas, {
                grup: grupId, produk: produkId, tanggal: form.tanggal,
            })
        } catch (e) {
            galatServer.value = e
        } finally {
            memuat.kapasitas = false
        }
    }

    /* ---------------- Computed Properties ---------------- */
    const resepTerpilih = computed(
        () => opsi.resep.find((r) => String(r.id) === String(form.resep_id))
    )

    const produkJadiId = computed(() => (
        form.jenis_sesi === 'PRODUKSI'
            ? resepTerpilih.value?.produk_jadi
            : form.produk_jadi_id
    ))

    const opsiProdukJadi = computed(() => {
        const seen = new Map()
        for (const r of opsi.resep) {
            if (!seen.has(r.produk_jadi)) {
                seen.set(r.produk_jadi, { id: r.produk_jadi, kode: r.produk_jadi_kode, nama: r.produk_jadi_nama })
            }
        }
        return [...seen.values()]
    })

    const stokById = (id) => opsi.stokPool.find((s) => String(s.id) === String(id))

    function opsiUntukBaris(i) {
        const terpakai = bahan.value
            .map((b, j) => (j === i ? null : b.stok_id))
            .filter(Boolean)
            .map(String)
        return opsi.stokPool.filter((s) => !terpakai.includes(String(s.id)))
    }

    const targetHasil = computed(() => angka(form.target_hasil))
    const maksimum = computed(() => angka(opsi.kapasitas?.maksimum))
    const pembatas = computed(() => opsi.kapasitas?.pembatas ?? [])

    const kebutuhanResep = computed(() => {
        if (form.jenis_sesi !== 'PRODUKSI' || !opsi.kapasitas) return []
        return opsi.kapasitas.rincian.map((r) => ({
            bahan_id: r.bahan_id,
            kode: r.bahan,
            tersedia: angka(r.tersedia),
            per_unit: angka(r.per_unit),
            butuh: angka(r.per_unit) * targetHasil.value,
            cukup: angka(r.tersedia) >= angka(r.per_unit) * targetHasil.value,
        }))
    })

    const barisTerisi = computed(
        () => bahan.value.filter((b) => b.stok_id && angka(b.qty) > 0)
    )

    const totalBahan = computed(() => (
        form.jenis_sesi === 'RND'
            ? barisTerisi.value.reduce((t, b) => t + angka(b.qty), 0)
            : kebutuhanResep.value.reduce((t, r) => t + r.butuh, 0)
    ))

    const susut = computed(() => totalBahan.value - targetHasil.value)
    const rendemen = computed(
        () => (totalBahan.value > 0 ? (targetHasil.value / totalBahan.value) * 100 : null)
    )

    const tangkiTerpilih = computed(
        () => opsi.tangki.find((t) => String(t.id) === String(form.tangki_hasil_id))
    )

    const galat = computed(() => {
        const g = {}
        if (!form.grup_bahan_id) g.grup_bahan_id = 'Pilih grup bahan (pool asal).'
        if (!form.tanggal) g.tanggal = 'Tanggal wajib diisi.'

        if (form.jenis_sesi === 'PRODUKSI') {
            if (!form.resep_id) g.resep_id = 'Pilih resep adonan.'
            if (maksimum.value > 0 && targetHasil.value > maksimum.value) {
                g.target_hasil =
                    `Bahan hanya cukup untuk ${tampil(maksimum.value)} unit` +
                    (pembatas.value.length ? ` (dibatasi ${pembatas.value.join(', ')})` : '') + '.'
            }
        } else {
            if (!form.produk_jadi_id) g.produk_jadi_id = 'Pilih produk hasil.'
            if (!barisTerisi.value.length) g.baris = 'Isi minimal satu bahan.'
        }

        if (form.mode_tangki === 'ada') {
            if (!form.tangki_hasil_id) {
                g.tangki_hasil_id = 'Pilih tangki perantara/tujuan.'
            } else {
                const t = tangkiTerpilih.value
                if (t && targetHasil.value > angka(t.ruang_kosong_kg)) {
                    g.tangki_hasil_id =
                        `Sisa ruang tangki ${t.kode} tinggal ${tampil(t.ruang_kosong_kg)} kg.`
                }
            }
        } else if (!TANGKI_BARU_TERSEDIA) {
            g.tangki_baru_kode =
                'Tangki baru belum bisa dibuat dari layar ini -- belum ada ' +
                'endpoint-nya di backend. Buat lewat Django admin dulu.'
        } else {
            const tb = form.tangki_baru
            if (!tb.kode.trim()) g.tangki_baru_kode = 'Kode tangki wajib diisi.'
            if (!tb.nama.trim()) g.tangki_baru_nama = 'Nama tangki wajib diisi.'
            if (angka(tb.kapasitas_kg) <= 0) g.tangki_baru_kapasitas = 'Kapasitas harus > 0.'
        }

        if (targetHasil.value <= 0) g.target_hasil = 'Target hasil wajib diisi.'
        return g
    })

    const peringatan = computed(() => {
        const p = []
        if (form.jenis_sesi === 'RND' && rendemen.value !== null && rendemen.value > 100) {
            p.push('Target hasil melebihi total bahan yang dipilih.')
        }
        for (const r of kebutuhanResep.value) {
            if (!r.cukup) {
                p.push(`Bahan ${r.kode} kurang: butuh ${tampil(r.butuh)}, tersedia ${tampil(r.tersedia)}.`)
            }
        }
        return p
    })

    const bisaKirim = computed(
        () => Object.keys(galat.value).length === 0 && !memuat.kirim
    )

    /* ---------------- Observers ---------------- */
    watch(() => form.grup_bahan_id, async (id) => {
        form.tangki_hasil_id = ''
        bahan.value = [barisKosong(), barisKosong(), barisKosong()]
        await muatIsiGrup(id)
        await muatKapasitas()
    })

    watch(() => [form.resep_id, form.produk_jadi_id, form.jenis_sesi, form.tanggal],
        () => { muatKapasitas() })

    /* ---------------- Actions ---------------- */
    function tambahBaris() { bahan.value.push(barisKosong()) }
    function hapusBaris(i) { if (bahan.value.length > 1) bahan.value.splice(i, 1) }

    function reset() {
        form.resep_id = ''
        form.produk_jadi_id = ''
        form.tangki_hasil_id = ''
        form.mode_tangki = 'ada'
        form.tangki_baru = { kode: '', nama: '', kapasitas_kg: '' }
        form.target_hasil = ''
        form.catatan = ''
        form.hasil_masuk_pool = true
        bahan.value = [barisKosong(), barisKosong(), barisKosong()]
        opsi.kapasitas = null
        sudahDicoba.value = false
        // Reset kunci idempotensi hanya setelah berhasil dikirim/direset utuh
        idemKey.value = buatIdemKey()
    }

    async function kirim() {
        sudahDicoba.value = true
        galatServer.value = null
        if (!bisaKirim.value) return

        memuat.kirim = true
        try {
            const dasar = {
                grup_bahan_id: Number(form.grup_bahan_id),
                qty_target: qty3(form.target_hasil),
                tanggal: form.tanggal,
                tangki_hasil_id: form.tangki_hasil_id ? Number(form.tangki_hasil_id) : null,
                catatan: form.catatan.trim(),
                idem_key: idemKey.value // Disisipkan ke payload untuk mencegah duplikasi batch
            }

            let hasilSesi
            if (form.jenis_sesi === 'PRODUKSI') {
                hasilSesi = await apiPost(API.sesi, {
                    ...dasar,
                    resep_id: Number(form.resep_id),
                })
            } else {
                const baris = barisTerisi.value.map((b) => {
                    const s = stokById(b.stok_id)
                    return {
                        bahan_id: Number(s.produk),
                        qty_rencana: qty3(b.qty),
                        tangki_id: s.tangki ? Number(s.tangki) : null,
                    }
                })
                hasilSesi = await apiPost(API.sesiRnd, {
                    ...dasar,
                    produk_jadi_id: Number(form.produk_jadi_id),
                    hasil_masuk_pool: form.hasil_masuk_pool,
                    baris,
                })
            }

            emit('tersimpan', hasilSesi)
            reset()
        } catch (e) {
            galatServer.value = e
        } finally {
            memuat.kirim = false
        }
    }

    const tampilkan = (kunci) => sudahDicoba.value && galat.value[kunci]
    const galatBaris = () => (sudahDicoba.value ? galat.value.baris : null)
    const galatServerField = (kunci) => galatServer.value?.perField?.[kunci] ?? null

    return {
        form,
        bahan,
        opsi,
        memuat,
        galatServer,
        galat,
        peringatan,
        bisaKirim,
        resepTerpilih,
        opsiProdukJadi,
        kebutuhanResep,
        maksimum,
        pembatas,
        totalBahan,
        targetHasil,
        susut,
        rendemen,
        muatDataAwal,
        muatKapasitas,
        stokById,
        opsiUntukBaris,
        tambahBaris,
        hapusBaris,
        kirim,
        reset,
        tampil,
        tampilkan,
        galatBaris,
        galatServerField,
    }
}